var class_auteur =
[
    [ "__construct", "class_auteur.html#aea0903437b3ae914f6e8e9de30614798", null ],
    [ "getClasseCouleur", "class_auteur.html#a0982924e7f53f9f9ac94a5ea5e76b6ee", null ],
    [ "getEmail", "class_auteur.html#a02a01849f28e2535e888ae4ec87b20f2", null ],
    [ "getGithub", "class_auteur.html#a9994cf5370984a61b9c335007db3777e", null ],
    [ "getInitiale", "class_auteur.html#ad3fe9f38fd66354595a985d2ab6b96f7", null ],
    [ "getLinkedin", "class_auteur.html#ac393a7f16a26b126935d69109e4424ed", null ],
    [ "getLocalisation", "class_auteur.html#af4c6e63ec88911de9b83741286710f71", null ],
    [ "getNom", "class_auteur.html#a184f2299ee4553fa0782ea87c9aed362", null ],
    [ "getPrenom", "class_auteur.html#a2a243ff78ccebcd417fd644325f44701", null ],
    [ "getRole", "class_auteur.html#a0b2e7098f1c48a7439a42bada5b69689", null ],
    [ "getTelephone", "class_auteur.html#a326c966f9bae22a950b35abec70bf2d3", null ]
];