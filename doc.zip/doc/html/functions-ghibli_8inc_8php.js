var functions_ghibli_8inc_8php =
[
    [ "getFilmsGhibli", "functions-ghibli_8inc_8php.html#a78cf39b9a663f03048f396bcbf40908c", null ],
    [ "getInfosFilm", "functions-ghibli_8inc_8php.html#ad4d0eaf109d6d2ae2b2015c19f46f3a5", null ],
    [ "getRandomFilm", "functions-ghibli_8inc_8php.html#ae1bde3b08889c3256b2d0f57b4163230", null ]
];