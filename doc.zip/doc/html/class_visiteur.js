var class_visiteur =
[
    [ "__construct", "class_visiteur.html#afe60fe0c874f5694ad59b0ad13528243", null ],
    [ "getAs", "class_visiteur.html#a24ce8d3eef8c5ecb6fa1d40b5331ecc2", null ],
    [ "getCodePays", "class_visiteur.html#a6407374aee3a3f63f8665aa591cf7af2", null ],
    [ "getCodePostal", "class_visiteur.html#a99317f86aa1788fa0bd119063eaa8875", null ],
    [ "getCodeRegion", "class_visiteur.html#a76b3f4346c6ac6b8622f366cc5c8e696", null ],
    [ "getIp", "class_visiteur.html#a4bf860bc339a9e83ea312a0051e367b9", null ],
    [ "getLatitude", "class_visiteur.html#ada96fc6a273160f91e3cf4ef59efbe9a", null ],
    [ "getLongitude", "class_visiteur.html#acaa3304699a7de6311b199939e00eaf3", null ],
    [ "getNomAsn", "class_visiteur.html#a5e10aa9c66e1d2e26f165e4a4e130a10", null ],
    [ "getPays", "class_visiteur.html#a6a14462759f0cbb85be5f07926655fab", null ],
    [ "getRegion", "class_visiteur.html#ab955facad00afb9d014661f76cb2a659", null ],
    [ "getVille", "class_visiteur.html#a5fdb46906b99db60cdc126d6e3c606c0", null ]
];