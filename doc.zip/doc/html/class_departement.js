var class_departement =
[
    [ "__construct", "class_departement.html#aaa2e422b76e13232f9e183333c98df23", null ],
    [ "getCode", "class_departement.html#ab5e24da53b4a0d0848b18c1e832f47ff", null ],
    [ "getNom", "class_departement.html#a184f2299ee4553fa0782ea87c9aed362", null ],
    [ "getRegion", "class_departement.html#ab955facad00afb9d014661f76cb2a659", null ]
];