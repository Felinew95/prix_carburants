var class_region =
[
    [ "__construct", "class_region.html#a50842959059f7331a2c461728caabbb6", null ],
    [ "getCode", "class_region.html#ab5e24da53b4a0d0848b18c1e832f47ff", null ],
    [ "getNom", "class_region.html#a184f2299ee4553fa0782ea87c9aed362", null ]
];