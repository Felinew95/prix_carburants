var annotated_dup =
[
    [ "Auteur", "class_auteur.html", "class_auteur" ],
    [ "Departement", "class_departement.html", "class_departement" ],
    [ "Film", "class_film.html", "class_film" ],
    [ "ObjectFactory", "class_object_factory.html", null ],
    [ "Region", "class_region.html", "class_region" ],
    [ "Station", "class_station.html", "class_station" ],
    [ "Ville", "class_ville.html", "class_ville" ],
    [ "Visiteur", "class_visiteur.html", "class_visiteur" ]
];