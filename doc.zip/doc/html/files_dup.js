var files_dup =
[
    [ "classes", "dir_b02e4219757ae4e3a0f1714873865bbf.html", "dir_b02e4219757ae4e3a0f1714873865bbf" ],
    [ "include", "dir_d44c64559bbebec7f509842c48db8b23.html", "dir_d44c64559bbebec7f509842c48db8b23" ],
    [ "config.php", "config_8php.html", "config_8php" ],
    [ "contacts.php", "contacts_8php.html", "contacts_8php" ],
    [ "index.php", "index_8php.html", "index_8php" ],
    [ "plan.php", "plan_8php.html", "plan_8php" ],
    [ "save_theme.php", "save__theme_8php.html", null ],
    [ "stats.php", "stats_8php.html", "stats_8php" ],
    [ "tech.php", "tech_8php.html", "tech_8php" ]
];