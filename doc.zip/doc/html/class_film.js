var class_film =
[
    [ "__construct", "class_film.html#a08853f2418788b8acdc94a65e7186d26", null ],
    [ "getBanniere", "class_film.html#a5e410d104bcf44134326d53d72e2f238", null ],
    [ "getDateSortie", "class_film.html#aba361bd8e01885c63603d3f7001d3d3e", null ],
    [ "getDescription", "class_film.html#a2e7bb35c71bf1824456ceb944cb7a845", null ],
    [ "getDuree", "class_film.html#a8738c3c8e09642c9f8f1239e9bfc1c91", null ],
    [ "getImage", "class_film.html#a2af8add37797384585cae101fb8cbfe7", null ],
    [ "getProducteur", "class_film.html#abf98aec4ef93d5b08bc4fa5ff1b97d1a", null ],
    [ "getRealisateur", "class_film.html#a1cf95c2ba9580b439e381c5a440038e5", null ],
    [ "getTitre", "class_film.html#a11c380e71778af9871c5bd84b2f50eae", null ],
    [ "getTitreOriginal", "class_film.html#adceff5af18093614a5ecafc038b5d3b0", null ],
    [ "getTitreOriginalRomanise", "class_film.html#a3237ff83a3cbcc6f24873aa970a50078", null ]
];