var searchData=
[
  ['weight_0',['weight',['../index_8php.html#aec12d33c8ae08c5554eab6b1c8cab442',1,'index.php']]]
];
