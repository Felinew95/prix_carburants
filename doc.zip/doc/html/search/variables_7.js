var searchData=
[
  ['if_0',['if',['../stats_8php.html#a4f5c2d0f894792fbe1a3d5c73a2bb477',1,'if:&#160;stats.php'],['../tech_8php.html#ad5d0cc339d41d9ced130487436772b7b',1,'if:&#160;tech.php']]]
];
