var searchData=
[
  ['zones_5fregions_0',['ZONES_REGIONS',['../config_8php.html#a61347ef511d210a76c5c28fe50e2be29',1,'config.php']]]
];
