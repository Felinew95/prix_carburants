var indexSectionsWithContent =
{
  0: "$_acdefghilnoprstvwz",
  1: "adforsv",
  2: "acdfhioprstv",
  3: "_cdegnorst",
  4: "$_acdefilnrstwz"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables"
};

